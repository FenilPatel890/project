import { Text, View, StyleSheet } from 'react-native';

import * as React from 'react';
import Feed from "./Screens/Feed"
import LoginScreen from "./Screens/LoginScreen"
import Profile from "./Screens/Profile"

import StackNavigator from "./Navigation/stackNavigator"
import {NavigationContainer} from '@react-navigation/native'

export default class App extends React.Component{
  render(){
    return(
      <NavigationContainer>
        <StackNavigator/>
      </NavigationContainer>
    )
  }
}