import firebase from "firebase";
require("@firebase/firestore");

 const firebaseConfig = {
  apiKey: "AIzaSyDIZVTBKZWlYaMkUWppUlEUSj9bSH_arRQ",
  authDomain: "studee-app-b428c.firebaseapp.com",
  projectId: "studee-app-b428c",
  storageBucket: "studee-app-b428c.appspot.com",
  messagingSenderId: "903037882670",
  appId: "1:903037882670:web:dd01d80c0ccca77fafaabf"
};

firebase.initializeApp(firebaseConfig);

export default firebase.firestore();