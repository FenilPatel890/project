import React, { Component } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Image
} from "react-native";

let customFonts = {
  "Bubblegum-Sans": require("../assets/Fonts/BubblegumSans-Regular.ttf")
};



export default class Profile extends Component {
    render() {
        return (
         <View>
          <Text style = {styles.headerText}> "Profile" </Text>
          <Text style = {styles.informationText}> "Name" </Text>
          <Text style = {styles.informationText}> "Class" </Text>
          <Text style = {styles.informationText}> "Email ID" </Text>
          <Text style = {styles.informationText}> "User ID" </Text>
          <Text style = {styles.informationText}> "Mobile NO" </Text>
          <Text style = {styles.informationText}> "Class" </Text>
         </View>
        )     
    }
}

const styles = StyleSheet.create({
 headerText: {
   fontSize: 30,
   fontColor: "dark grey",
   textAlign: 'Center'
 },
 informationText: {
   fontSize: 15,
   fontColor: "black",
   textAlign: "Right"
   fontWeight: 10
 },
})